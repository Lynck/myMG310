################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Code/Grayscale_Sensor.c \
../Code/PID.c \
../Code/encoder.c \
../Code/motor.c \
../Code/motor_speed.c \
../Code/myBluetooth.c \
../Code/myGSensor.c \
../Code/myOLED.c \
../Code/myPID.c \
../Code/myTask.c \
../Code/single_axis_gyro.c 

C_DEPS += \
./Code/Grayscale_Sensor.d \
./Code/PID.d \
./Code/encoder.d \
./Code/motor.d \
./Code/motor_speed.d \
./Code/myBluetooth.d \
./Code/myGSensor.d \
./Code/myOLED.d \
./Code/myPID.d \
./Code/myTask.d \
./Code/single_axis_gyro.d 

OBJS += \
./Code/Grayscale_Sensor.o \
./Code/PID.o \
./Code/encoder.o \
./Code/motor.o \
./Code/motor_speed.o \
./Code/myBluetooth.o \
./Code/myGSensor.o \
./Code/myOLED.o \
./Code/myPID.o \
./Code/myTask.o \
./Code/single_axis_gyro.o 

OBJS__QUOTED += \
"Code\Grayscale_Sensor.o" \
"Code\PID.o" \
"Code\encoder.o" \
"Code\motor.o" \
"Code\motor_speed.o" \
"Code\myBluetooth.o" \
"Code\myGSensor.o" \
"Code\myOLED.o" \
"Code\myPID.o" \
"Code\myTask.o" \
"Code\single_axis_gyro.o" 

C_DEPS__QUOTED += \
"Code\Grayscale_Sensor.d" \
"Code\PID.d" \
"Code\encoder.d" \
"Code\motor.d" \
"Code\motor_speed.d" \
"Code\myBluetooth.d" \
"Code\myGSensor.d" \
"Code\myOLED.d" \
"Code\myPID.d" \
"Code\myTask.d" \
"Code\single_axis_gyro.d" 

C_SRCS__QUOTED += \
"../Code/Grayscale_Sensor.c" \
"../Code/PID.c" \
"../Code/encoder.c" \
"../Code/motor.c" \
"../Code/motor_speed.c" \
"../Code/myBluetooth.c" \
"../Code/myGSensor.c" \
"../Code/myOLED.c" \
"../Code/myPID.c" \
"../Code/myTask.c" \
"../Code/single_axis_gyro.c" 



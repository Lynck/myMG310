# FIXED

Code/single_axis_gyro.o: ../Code/single_axis_gyro.c \
 ../Code/single_axis_gyro.h
../Code/single_axis_gyro.h:

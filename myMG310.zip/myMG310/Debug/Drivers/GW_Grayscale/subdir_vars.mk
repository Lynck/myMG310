################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/GW_Grayscale/gw_grayscale.c \
../Drivers/GW_Grayscale/gw_grayscale_mspm0.c 

C_DEPS += \
./Drivers/GW_Grayscale/gw_grayscale.d \
./Drivers/GW_Grayscale/gw_grayscale_mspm0.d 

OBJS += \
./Drivers/GW_Grayscale/gw_grayscale.o \
./Drivers/GW_Grayscale/gw_grayscale_mspm0.o 

OBJS__QUOTED += \
"Drivers\GW_Grayscale\gw_grayscale.o" \
"Drivers\GW_Grayscale\gw_grayscale_mspm0.o" 

C_DEPS__QUOTED += \
"Drivers\GW_Grayscale\gw_grayscale.d" \
"Drivers\GW_Grayscale\gw_grayscale_mspm0.d" 

C_SRCS__QUOTED += \
"../Drivers/GW_Grayscale/gw_grayscale.c" \
"../Drivers/GW_Grayscale/gw_grayscale_mspm0.c" 



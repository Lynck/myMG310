# FIXED

Drivers/GW_Grayscale/gw_grayscale.o: \
 ../Drivers/GW_Grayscale/gw_grayscale.c \
 ../Drivers/GW_Grayscale/gw_grayscale.h
../Drivers/GW_Grayscale/gw_grayscale.h:

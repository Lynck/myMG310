/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2500
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMG7
#define PWM_MOTOR_INST_IRQHandler                               TIMG7_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMG7_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                         10000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C0_PIN                                     DL_GPIO_PIN_26
#define GPIO_PWM_MOTOR_C0_IOMUX                                  (IOMUX_PINCM59)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                 IOMUX_PINCM59_PF_TIMG7_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C1_PIN                                     DL_GPIO_PIN_24
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM54)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM54_PF_TIMG7_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX



/* Defines for TIMER_100MS */
#define TIMER_100MS_INST                                                 (TIMA0)
#define TIMER_100MS_INST_IRQHandler                             TIMA0_IRQHandler
#define TIMER_100MS_INST_INT_IRQN                               (TIMA0_INT_IRQn)
#define TIMER_100MS_INST_LOAD_VALUE                                      (9999U)
/* Defines for TIMER_10MS */
#define TIMER_10MS_INST                                                  (TIMA1)
#define TIMER_10MS_INST_IRQHandler                              TIMA1_IRQHandler
#define TIMER_10MS_INST_INT_IRQN                                (TIMA1_INT_IRQn)
#define TIMER_10MS_INST_LOAD_VALUE                                        (999U)



/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                           40000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOA
#define GPIO_UART_2_TX_PORT                                                GPIOA
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_22
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_21
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM47)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM46)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM47_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM46_PF_UART2_TX
#define UART_2_BAUD_RATE                                                (115200)
#define UART_2_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_2_FBRD_40_MHZ_115200_BAUD                                      (45)




/* Defines for SPI_IMU660RB */
#define SPI_IMU660RB_INST                                                  SPI0
#define SPI_IMU660RB_INST_IRQHandler                            SPI0_IRQHandler
#define SPI_IMU660RB_INST_INT_IRQN                                SPI0_INT_IRQn
#define GPIO_SPI_IMU660RB_PICO_PORT                                       GPIOA
#define GPIO_SPI_IMU660RB_PICO_PIN                                DL_GPIO_PIN_9
#define GPIO_SPI_IMU660RB_IOMUX_PICO                            (IOMUX_PINCM20)
#define GPIO_SPI_IMU660RB_IOMUX_PICO_FUNC            IOMUX_PINCM20_PF_SPI0_PICO
#define GPIO_SPI_IMU660RB_POCI_PORT                                       GPIOA
#define GPIO_SPI_IMU660RB_POCI_PIN                               DL_GPIO_PIN_13
#define GPIO_SPI_IMU660RB_IOMUX_POCI                            (IOMUX_PINCM35)
#define GPIO_SPI_IMU660RB_IOMUX_POCI_FUNC            IOMUX_PINCM35_PF_SPI0_POCI
/* GPIO configuration for SPI_IMU660RB */
#define GPIO_SPI_IMU660RB_SCLK_PORT                                       GPIOA
#define GPIO_SPI_IMU660RB_SCLK_PIN                               DL_GPIO_PIN_12
#define GPIO_SPI_IMU660RB_IOMUX_SCLK                            (IOMUX_PINCM34)
#define GPIO_SPI_IMU660RB_IOMUX_SCLK_FUNC            IOMUX_PINCM34_PF_SPI0_SCLK



/* Defines for ADC_BUTTON */
#define ADC_BUTTON_INST                                                     ADC0
#define ADC_BUTTON_INST_IRQHandler                               ADC0_IRQHandler
#define ADC_BUTTON_INST_INT_IRQN                                 (ADC0_INT_IRQn)
#define ADC_BUTTON_ADCMEM_0                                   DL_ADC12_MEM_IDX_0
#define ADC_BUTTON_ADCMEM_0_REF                  DL_ADC12_REFERENCE_VOLTAGE_VDDA
#define ADC_BUTTON_ADCMEM_0_REF_VOLTAGE_V                                     3.3
#define GPIO_ADC_BUTTON_C0_PORT                                            GPIOA
#define GPIO_ADC_BUTTON_C0_PIN                                    DL_GPIO_PIN_27
#define GPIO_ADC_BUTTON_IOMUX_C0                                 (IOMUX_PINCM60)
#define GPIO_ADC_BUTTON_IOMUX_C0_FUNC             (IOMUX_PINCM60_PF_UNCONNECTED)



/* Port definition for Pin Group AIN1 */
#define AIN1_PORT                                                        (GPIOA)

/* Defines for PIN_2: GPIOA.2 with pinCMx 7 on package pin 8 */
#define AIN1_PIN_2_PIN                                           (DL_GPIO_PIN_2)
#define AIN1_PIN_2_IOMUX                                          (IOMUX_PINCM7)
/* Port definition for Pin Group AIN2 */
#define AIN2_PORT                                                        (GPIOB)

/* Defines for PIN_24: GPIOB.24 with pinCMx 52 on package pin 42 */
#define AIN2_PIN_24_PIN                                         (DL_GPIO_PIN_24)
#define AIN2_PIN_24_IOMUX                                        (IOMUX_PINCM52)
/* Port definition for Pin Group BIN1 */
#define BIN1_PORT                                                        (GPIOB)

/* Defines for PIN_20: GPIOB.20 with pinCMx 48 on package pin 41 */
#define BIN1_PIN_20_PIN                                         (DL_GPIO_PIN_20)
#define BIN1_PIN_20_IOMUX                                        (IOMUX_PINCM48)
/* Port definition for Pin Group BIN2 */
#define BIN2_PORT                                                        (GPIOB)

/* Defines for PIN_7: GPIOB.7 with pinCMx 24 on package pin 21 */
#define BIN2_PIN_7_PIN                                           (DL_GPIO_PIN_7)
#define BIN2_PIN_7_IOMUX                                         (IOMUX_PINCM24)
/* Port definition for Pin Group STBY */
#define STBY_PORT                                                        (GPIOB)

/* Defines for PIN_8: GPIOB.8 with pinCMx 25 on package pin 22 */
#define STBY_PIN_8_PIN                                           (DL_GPIO_PIN_8)
#define STBY_PIN_8_IOMUX                                         (IOMUX_PINCM25)
/* Port definition for Pin Group GPIO_IMU660RB */
#define GPIO_IMU660RB_PORT                                               (GPIOA)

/* Defines for PIN_IMU660RB_CS: GPIOA.15 with pinCMx 37 on package pin 30 */
#define GPIO_IMU660RB_PIN_IMU660RB_CS_PIN                       (DL_GPIO_PIN_15)
#define GPIO_IMU660RB_PIN_IMU660RB_CS_IOMUX                      (IOMUX_PINCM37)
/* Port definition for Pin Group SCL */
#define SCL_PORT                                                         (GPIOB)

/* Defines for SCK_PIN: GPIOB.2 with pinCMx 15 on package pin 14 */
#define SCL_SCK_PIN_PIN                                          (DL_GPIO_PIN_2)
#define SCL_SCK_PIN_IOMUX                                        (IOMUX_PINCM15)
/* Port definition for Pin Group SDA */
#define SDA_PORT                                                         (GPIOB)

/* Defines for SDA_PIN: GPIOB.3 with pinCMx 16 on package pin 15 */
#define SDA_SDA_PIN_PIN                                          (DL_GPIO_PIN_3)
#define SDA_SDA_PIN_IOMUX                                        (IOMUX_PINCM16)
/* Port definition for Pin Group BUZZER */
#define BUZZER_PORT                                                      (GPIOB)

/* Defines for PIN_9: GPIOB.9 with pinCMx 26 on package pin 23 */
#define BUZZER_PIN_9_PIN                                         (DL_GPIO_PIN_9)
#define BUZZER_PIN_9_IOMUX                                       (IOMUX_PINCM26)
/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOA)

/* Defines for PIN_5: GPIOA.5 with pinCMx 10 on package pin 11 */
#define LED_PIN_5_PIN                                            (DL_GPIO_PIN_5)
#define LED_PIN_5_IOMUX                                          (IOMUX_PINCM10)
/* Port definition for Pin Group ENC_A_DIR */
#define ENC_A_DIR_PORT                                                   (GPIOB)

/* Defines for PIN_18: GPIOB.18 with pinCMx 44 on package pin 37 */
#define ENC_A_DIR_PIN_18_PIN                                    (DL_GPIO_PIN_18)
#define ENC_A_DIR_PIN_18_IOMUX                                   (IOMUX_PINCM44)
/* Port definition for Pin Group ENC_B_DIR */
#define ENC_B_DIR_PORT                                                   (GPIOA)

/* Defines for PIN_25: GPIOA.25 with pinCMx 55 on package pin 45 */
#define ENC_B_DIR_PIN_25_PIN                                    (DL_GPIO_PIN_25)
#define ENC_B_DIR_PIN_25_IOMUX                                   (IOMUX_PINCM55)
/* Port definition for Pin Group GPIO_OLED */
#define GPIO_OLED_PORT                                                   (GPIOA)

/* Defines for PIN_OLED_SCL: GPIOA.1 with pinCMx 2 on package pin 2 */
#define GPIO_OLED_PIN_OLED_SCL_PIN                               (DL_GPIO_PIN_1)
#define GPIO_OLED_PIN_OLED_SCL_IOMUX                              (IOMUX_PINCM2)
/* Defines for PIN_OLED_SDA: GPIOA.0 with pinCMx 1 on package pin 1 */
#define GPIO_OLED_PIN_OLED_SDA_PIN                               (DL_GPIO_PIN_0)
#define GPIO_OLED_PIN_OLED_SDA_IOMUX                              (IOMUX_PINCM1)
/* Port definition for Pin Group GPIO_ENCODER */
#define GPIO_ENCODER_PORT                                                (GPIOA)

/* Defines for PIN_A: GPIOA.8 with pinCMx 19 on package pin 16 */
// pins affected by this interrupt request:["PIN_A","PIN_B"]
#define GPIO_ENCODER_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_ENCODER_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_PIN_A_IIDX                              (DL_GPIO_IIDX_DIO8)
#define GPIO_ENCODER_PIN_A_PIN                                   (DL_GPIO_PIN_8)
#define GPIO_ENCODER_PIN_A_IOMUX                                 (IOMUX_PINCM19)
/* Defines for PIN_B: GPIOA.16 with pinCMx 38 on package pin 31 */
#define GPIO_ENCODER_PIN_B_IIDX                             (DL_GPIO_IIDX_DIO16)
#define GPIO_ENCODER_PIN_B_PIN                                  (DL_GPIO_PIN_16)
#define GPIO_ENCODER_PIN_B_IOMUX                                 (IOMUX_PINCM38)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_TIMER_100MS_init(void);
void SYSCFG_DL_TIMER_10MS_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_SPI_IMU660RB_init(void);
void SYSCFG_DL_ADC_BUTTON_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
